CREATE TABLE `chargehq_intervals` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `start_time_epoch` integer NOT NULL,
  `start_time_local` text NOT NULL,
  `charged_wh` real NOT NULL,
  `solar_wh` real NOT NULL,
  `battery_wh` real NOT NULL,
  `grid_wh` real NOT NULL,
  `away_wh` real NOT NULL,
  `at_home_wh` real NOT NULL,
  `source_file` text NOT NULL,
  `imported_at` text DEFAULT (datetime('now')) NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_chargehq_interval_epoch` ON `chargehq_intervals` (`start_time_epoch`);
--> statement-breakpoint
CREATE INDEX `idx_chargehq_local_time` ON `chargehq_intervals` (`start_time_local`);
